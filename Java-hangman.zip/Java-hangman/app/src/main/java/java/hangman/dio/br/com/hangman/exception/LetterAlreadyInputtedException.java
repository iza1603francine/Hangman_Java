package java.hangman.dio.br.com.hangman.exception;

public class LetterAlreadyInputtedException extends RuntimeExceptions {
   public LetterAlreadyInputtedException(String message){
        super(message);
    } 

}
