package java.hangman.dio.br.com.hangman;

import java.hangman.dio.br.com.hangman.exception.GameIsFinishedException;
import java.hangman.dio.br.com.hangman.exception.LetterAlreadyInputtedException;
import java.hangman.dio.br.com.hangman.model.HangmanChar;
import java.hangman.dio.br.com.hangman.model.HangmanGame;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Stream;

public class Main {

    private final static Scanner scanner = new Scanner(System.in);
    public static void main(String... args){
        List<HangmanChar> characters = Stream.of(args)
            .map(a -> a.toLowerCase().charAt(0))
            .map(HangmanChar::new).toList();

        System.out.println(characters);
        var hangmanGame = new HangmanGame(characters);
        System.out.println("Bem vindo ao Jogo da Forca, tente adivinhar a palavra!");
        System.out.println(hangmanGame);
        var option = -1;
        while (true){
            System.out.println("Selecione uma das opções: ");
            System.out.println(" 1 - Informar uma letra");
            System.out.println(" 2 - Verificar Status do Jogo");
            System.out.println(" 3 - Sair do Jogo");
            option = scanner.nextInt();
            switch (option){
                case 1 -> inputCharacter(hangmanGame);
                case 2 -> System.out.println(hangmanGame.getHangmanGameStatus());
                case 3 -> System.exit(0);
                default -> System.out.println("Opção Inválida!");
            }
        }

        private static void extracted(final HangmanGame hangmanGame){
        System.out.println("Informe uma letra: ");
                var character = scanner.next().charAt(0);
                try{
                    hangmanGame.inputCharacter(character);
                } catch (final LetterAlreadyInputtedException ex) {
                    System.out.println(ex.getMessage());
                    System.out.println(hangmanGame);    
                }   catch(GameIsFinishedException ex){
                    System.out.println(ex.getMessage());
                    System.exit(0);
                }
        }
        /*System.out.println(hangmanGame);
        hangmanGame.inputCharacter('t');
        System.out.println(hangmanGame);
        hangmanGame.inputCharacter('e');
        System.out.println(hangmanGame);
        hangmanGame.inputCharacter('s');
        System.out.println(hangmanGame);
        hangmanGame.inputCharacter('t');*/

    }

}
