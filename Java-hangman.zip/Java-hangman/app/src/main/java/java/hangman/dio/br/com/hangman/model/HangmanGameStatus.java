package java.hangman.dio.br.com.hangman.model;

public enum HangmanGameStatus {
    PENDING,
    WIN,
    LOSE

}
